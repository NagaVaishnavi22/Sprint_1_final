package com.cg.onlineeyecare.controller;
import java.util.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.onlineeyecare.dto.Appointment;
import com.cg.onlineeyecare.dto.Doctor;
import com.cg.onlineeyecare.dto.test;
import com.cg.onlineeyecare.exceptions.DoctorIdNotFoundException;
import com.cg.onlineeyecare.service.AppointmentService;
import com.cg.onlineeyecare.service.IDoctorService;
import com.cg.onlineeyecare.service.ITestService;

import io.swagger.annotations.Api;

/************************************************************************************
 *          @author          K.Muni Madhuri
 *          Description      It is a controller class that controls the data flow into model object 
 *                           and updates the view whenever data changes
  *         Version          1.0
  *         Created Date     22-MARCH-2021
 ************************************************************************************/


@Api
@RestController
@RequestMapping("/onlineeyeclinic")
public class DoctorController {
  @Autowired
	IDoctorService doctorService;
  @Autowired
	ITestService testService;
  @Autowired
  AppointmentService appointmentRepo;

	/************************************************************************************
 	 * Method:                          addDoctor
     *Description:                      It is used to add Doctor into Doctor table
     * @param doctor:                   test's reference variable.
 	 * @returns doctor                  It returns doctor with details
 	 * @PostMapping:                    It  is used to handle POST type of request method
 	 * @RequestBody:                    It maps the HttpRequest body to a transfer or domain object
     *Created By                      - K.Muni Madhuri
     *Created Date                    - 22-MARCH-2021                           
 	 
 	 ************************************************************************************/
	
  @PostMapping("/adddoctor")
  public Doctor addDoctor(@RequestBody Doctor doctor)
  {
  	return doctorService.addDoctor(doctor);
  }
	
	/************************************************************************************
	 * Method:                          viewDoctorsList
     *Description:                      To display all the doctors details
	 * @returns List<doctor>          - It returns all the doctors present in database
	 * @GetMapping:                     It is used to handle GET type of request method.
     *Created By                      - K.Muni Madhuri
     *Created Date                    - 22-MARCH-2021                           
	 
	 ************************************************************************************/

  @GetMapping("/viewdoctorslist")
  public List<Doctor>viewDoctorsList()
  {
  	return doctorService.viewDoctorsList();
  }
	
	/************************************************************************************
	 * Method:                          viewDoctor
     *Description:                      To display the doctor by Id (Primary key)
     *@param doctorid:                   id of the doctor.
	 * @returns doctor                  - if doctor with Id presents it returns doctor else throws DoctorIdNotFoundException
	 * @throws DoctorIdNotFoundException- It is raised due to invalid  DoctorId 
	 * @GetMapping:                     It is used to is used to handle GET type of request method.
	 * @PathVariable:                   It  is used for data passed in the URI and transfer its values to parameter variables.
     *Created By                      -K.Muni Madhuri
     *Created Date                    - 22-MARCH-2021                           
	 
	 ************************************************************************************/
	
	@GetMapping("/viewdoctor/{id}")
	public Doctor viewDoctor(@PathVariable int id) throws DoctorIdNotFoundException
	{
		return doctorService.viewDoctor(id);
	}
	
	/************************************************************************************
 	 * Method:                           deleteDoctor
      *Description:                      It is used to remove doctor
      *@param doctor:                    doctors's reference variable.
 	 * @returns doctor                   It returns the doctor that has been deleted
 	 * @throws DoctorIdNotFoundException:It is raised due to invalid doctor.
 	 * @DeletetMapping:                   It  is used to handle DELETE type of request method.
 	 * @RequestBody:                     It maps the HttpRequest body to a transfer or domain object
     *Created By                       -K.Muni Madhuri
     *Created Date                     - 22-MARCH-2021                           
 	 
 	 ************************************************************************************/
	
	@DeleteMapping("/deletedoctor/{id}")
	public Doctor deleteDoctor(@PathVariable int id) throws DoctorIdNotFoundException
	{
		return doctorService.deleteDoctor(id);
	}
	
	 /************************************************************************************
		 * Method:                          updateDoctor
	     *Description:                      It is used to update doctor details into doctor table.
	     * @param doctor:                   Doctor's reference variable.
	 * @throws DoctorIdNotFoundException 
		 * @returns doctor                  It returns updated details of the existed doctor.
		 * @PutMapping:                     It  is used to handle PUT type of request method
		 * @RequestBody:                    It maps the HttpRequest body to a transfer or domain object
	     *Created By                    -   K.Muni Madhuri
	     *Created Date                  -   22-MARCH-2021                           
		 
		 ************************************************************************************/
	
	@PutMapping("/updatedoctor")
	public Doctor updateDoctor(@RequestBody Doctor doctor) throws DoctorIdNotFoundException
	{
		return doctorService.updateDoctor(doctor);
	}
	/************************************************************************************
 	 * Method:                          createTest
     *Description:                      It is used to add Test into test table
     * @param test:                     test's reference variable.
 	 * @returns test                    It returns test with details
 	 * @RequestMapping:                    It  is used to handle POST type of request method
 	 * @RequestBody:                    It maps the HttpRequest body to a transfer or domain object
     *Created By                      - K.Muni Madhuri
     *Created Date                    - 22-MARCH-2021                           
 	 
 	 ************************************************************************************/
	
	@PostMapping("/createTest")
	public test createTest(@RequestBody test test) {
		return testService.addTest(test);
	}
	
	/************************************************************************************
	 * Method:                          viewallAppointments
     *Description:                      To display all the appointments
	 * @returns List<appointment>      - It returns all the appointments present in database
	 * @RequestMapping:                 It is used to handle GET type of request method.
     *Created By                      - K.Muni Madhuri
     *Created Date                    - 22-MARCH-2021                           
	 
	 ************************************************************************************/
	
	@GetMapping("/viewallappointments")
	public List<Appointment> listallappointments() {
		return appointmentRepo.viewAllAppointments();
	}
	
}

