package com.cg.onlineeyecare.controller;
import java.time.LocalDate;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.onlineeyecare.dto.Appointment;
import com.cg.onlineeyecare.dto.Patient;
import com.cg.onlineeyecare.exceptions.AppointmentIdNotFoundException;
import com.cg.onlineeyecare.exceptions.PatientIdFoundNotException;
import com.cg.onlineeyecare.service.PatientService;
import io.swagger.annotations.Api;
/************************************************************************************
 *          @author          Rushitha
 *          Description      It is a controller class that controls the data flow into model object 
 *                           and updates the view whenever data changes
  *         Version          1.0
  *         Created Date     25-MARCH-2021
 ************************************************************************************/
@Api
@RestController
@RequestMapping("/v1/patient")
public class PatientController {
  @Autowired
  PatientService patientRepo;

/************************************************************************************
 * Method:                          addpatient
*Description:                      It is used to add Patient into patient table
* @param patient:                     patient's reference variable.
 * @returns patient                    It returns patient with details
 * @PostMapping:                    It  is used to handle POST type of request method
 * @RequestBody:                    It maps the HttpRequest body to a transfer or domain object
*Created By                      - Rushitha
*Created Date                    - 25-MARCH-2021                           
 
 ************************************************************************************/

@PostMapping("/addpatient")
public Patient additionofPatient(@RequestBody Patient patient)
{
	return patientRepo.addPatient(patient);
}
/************************************************************************************
 * Method:                          updateTest
 *Description:                      It is used to update patient details into patient table.
 * @param patient:                     Patient's reference variable.
 * @returns patient                    It returns updated details of the existed patient.
 * @PuttMapping:                    It  is used to handle PUT type of request method
 * @RequestBody:                    It maps the HttpRequest body to a transfer or domain object
 *Created By                    -   Rushitha
 *Created Date                  -   25-MARCH-2021                           
 
 ************************************************************************************/
@PutMapping("/updatepatient")
public Patient updatepatient(@RequestBody Patient patient)
{
	return patientRepo.updatePatient(patient);
}
/************************************************************************************
	 * Method:                           deletepatient
  *Description:                      It is used to delete patient
  *@param patient:                      patient's reference variable.
	 * @returns patient                     It returns the patient that has been deleted
	 * @throws PatientIdNotFoundException:  It is raised due to invalid test.
	 * @DeleteMapping:                   It  is used to handle DELETE type of request method.
	 * @RequestBody:                     It maps the HttpRequest body to a transfer or domain object
 *Created By                       - Rushitha
 *Created Date                     - 25-MARCH-2021                           
	 
	 ************************************************************************************/
@DeleteMapping("/delete/{id}")
public Patient deltePatient(@PathVariable int id) throws PatientIdFoundNotException
{
	return patientRepo.deletePatient(id);
}

/************************************************************************************
 * Method:                          viewAllPatients
 *Description:                      To display all the patients
 * @returns List<patient>            - It returs all the patients present in database
 * @GetMapping:                     It is used to handle GET type of request method.
 *Created By                      - Rushitha
 *Created Date                    - 25-MARCH-2021                           
 
 ************************************************************************************/
@GetMapping("/viewpatientlist")
public List<Patient>listpatientlist()
{
	return patientRepo.viewPatientList();
}
/************************************************************************************
 * Method:                          viewpatient
 *Description:                      To display the patient by Id (Primary key)
 *@param patientid:                        id of the patient.
 * @returns patient                  - if patient with Id presents it returns patient else throws PatientIdNotFoundException
 * @throws PatientIdNotFoundException  - It is raised due to invalid  patientId 
 * @GetMapping:                     It is used to is used to handle GET type of request method.
 * @PathVariable:                   It  is used for data passed in the URI and transfer its values to parameter variables.
 *Created By                      - Rushitha
 *Created Date                    - 25-MARCH-2021                           
 
 ************************************************************************************/

@GetMapping("/viewpatient/{id}")
public Patient viewPatient(@PathVariable int id) throws PatientIdFoundNotException
{
	return patientRepo.viewPatient(id);
}

@PostMapping("/bookappointment")
public Appointment bookAppointment(@RequestBody Appointment appointment) {
	return patientRepo.bookAppointment(appointment);
}
@GetMapping("/viewappointment/{id}")
public Appointment viewAppointmentIn(@PathVariable int id) throws AppointmentIdNotFoundException {
	return patientRepo.viewAppointmentDetail(id);
}
}