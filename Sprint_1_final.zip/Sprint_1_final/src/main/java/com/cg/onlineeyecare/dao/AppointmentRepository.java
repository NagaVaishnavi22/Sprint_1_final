package com.cg.onlineeyecare.dao;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.onlineeyecare.dto.Appointment;
import com.cg.onlineeyecare.exceptions.AppointmentIdNotFoundException;
import com.cg.onlineeyecare.exceptions.InvalidAppointmentException;
import com.sun.el.stream.Optional;
@Repository
public interface AppointmentRepository extends  JpaRepository<Appointment,Integer> {

}
