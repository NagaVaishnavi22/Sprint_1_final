package com.cg.onlineeyecare.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cg.onlineeyecare.dto.Appointment;
import com.cg.onlineeyecare.dto.Doctor;
import com.cg.onlineeyecare.dto.test;


/************************************************************************************
 *          @author          K.Muni Madhuri
 *          Description      It is a doctor repository interface that extends jpa repository 
 *                           that contains inbuilt methods for various operations
  *         Version             1.0
  *         Created Date      22-MARCH-2021
 ************************************************************************************/

@Repository
public interface IDoctorRepository extends JpaRepository<Doctor, Integer> {

	
}

