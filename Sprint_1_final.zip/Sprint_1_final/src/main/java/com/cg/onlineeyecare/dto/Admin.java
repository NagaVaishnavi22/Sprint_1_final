package com.cg.onlineeyecare.dto;

import javax.persistence.Entity;
import javax.persistence.Id;
/*************************************************************************
 * @author               P.saiteja reddy
 * Description           It is a entity class that provides the details of the admin
 * Version               1.0
 * created date          24-03-2021    
 ***************************************************************************/
@Entity
public class Admin {
	@Id
	private int adminId;
	private String adminUsername;
	private String adminPassword;

	public int getAdminId() {
		return adminId;
	}

	public void setAdminId(int adminId) {
		this.adminId = adminId;
	}

	public String getAdminUsername() {
		return adminUsername;
	}

	public void setAdminUsername(String adminUsername) {
		this.adminUsername = adminUsername;
	}

	public String getAdminPassword() {
		return adminPassword;
	}

	public void setAdminPassword(String adminPassword) {
		this.adminPassword = adminPassword;
	}

	/************************************************************************************
	 * Method: admin 
	 * Description: It is used to initialize the empty constructor.
	 * Created By - p.saiteja reddy Created Date - 24-MARCH-2021
	 */
	public Admin() {
		super();
	}

	/************************************************************************************
	 * Method: admin 
	 * Description: It is used to initialize the parameterizedconstructor.
	 * @param adminId:       test's Id.
	 * @param adminUsername: test's Name.
	 * @param adminPassword: test's Type. 
	 * Created By - p.saitejareddy 
	 * Created Date -24-MARCH-2021
	 * 
	 ************************************************************************************/
	public Admin(int adminId, String adminUsername, String adminPassword) {
		super();
		this.adminId = adminId;
		this.adminUsername = adminUsername;
		this.adminPassword = adminPassword;
	}
}
