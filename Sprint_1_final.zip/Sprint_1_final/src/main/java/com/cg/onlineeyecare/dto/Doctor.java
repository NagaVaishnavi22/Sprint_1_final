package com.cg.onlineeyecare.dto;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

import com.cg.onlineeyecare.dto.test;
import com.fasterxml.jackson.annotation.JsonIgnore;

/************************************************************************************
 * @author K.Muni Madhuri 
 * Description It is a entity class that provides the details of the doctor 
 * Version 1.0 
 * Created Date 22-MARCH-2021
 ************************************************************************************/

@Entity
public class Doctor {
	@Id
	public Integer doctorId;
	private String doctorName;
	private String doctorConsultationTime;
	private long doctorMobile;
	private String doctorEmail;
	private String doctorUsername;
	private String doctorPassword;
	private String doctorAddress;
	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "doctorId")
	public List<test> tests;
	@OneToMany(cascade = CascadeType.MERGE)
	@JoinColumn(name = "doctorId")
	public List<Appointment> appointments;

	public Integer getDoctorId() {
		return doctorId;
	}

	public void setDoctorId(Integer doctorId) {
		this.doctorId = doctorId;
	}

	public String getDoctorName() {
		return doctorName;
	}

	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}

	public String getDoctorConsultationTime() {
		return doctorConsultationTime;
	}

	public void setDoctorConsultationTime(String doctorConsultationTime) {
		this.doctorConsultationTime = doctorConsultationTime;
	}

	public long getDoctorMobile() {
		return doctorMobile;
	}

	public void setDoctorMobile(long doctorMobile) {
		this.doctorMobile = doctorMobile;
	}

	public String getDoctorEmail() {
		return doctorEmail;
	}

	public void setDoctorEmail(String doctorEmail) {
		this.doctorEmail = doctorEmail;
	}

	public String getDoctorUsername() {
		return doctorUsername;
	}

	public void setDoctorUsername(String doctorUsername) {
		this.doctorUsername = doctorUsername;
	}

	public String getDoctorPassword() {
		return doctorPassword;
	}

	public void setDoctorPassword(String doctorPassword) {
		this.doctorPassword = doctorPassword;
	}

	public String getDoctorAddress() {
		return doctorAddress;
	}

	public void setDoctorAddress(String doctorAddress) {
		this.doctorAddress = doctorAddress;
	}

	/************************************************************************************
	 * Method: Doctor Description: It is used to initialize the empty constructor.
	 * Created By - K.Muni Madhuri Created Date - 22-MARCH-2021
	 * 
	 ************************************************************************************/

	public Doctor() {
		super();
	}

	/************************************************************************************
	 * Method: Doctor Description: It is used to initialize the parameterized
	 * constructor.
	 * 
	 * @param doctorId:               doctor's Id.
	 * @param doctorName:             doctor's Name.
	 * @param doctorConsultationTime: doctor's consultation time.
	 * @param doctorMobile:           doctor's Mobile.
	 * @param doctorEmail:            doctor's Email.
	 * @param doctorUsername:         doctor's Username
	 * @param doctorPassword:         doctor's Password
	 * @param doctorAddress:          doctor's Address Created By - K.Muni Madhuri
	 *                                Created Date - 22-MARCH-2021
	 * 
	 ************************************************************************************/

	public Doctor(Integer doctorId, String doctorName, String doctorConsultationTime, long doctorMobile,
			String doctorEmail, String doctorUsername, String doctorPassword, String doctorAddress, List<test> tests) {
		super();
		this.doctorId = doctorId;
		this.doctorName = doctorName;
		this.doctorConsultationTime = doctorConsultationTime;
		this.doctorMobile = doctorMobile;
		this.doctorEmail = doctorEmail;
		this.doctorUsername = doctorUsername;
		this.doctorPassword = doctorPassword;
		this.doctorAddress = doctorAddress;
		this.tests = tests;
	}

}
