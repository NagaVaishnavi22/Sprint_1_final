package com.cg.onlineeyecare.exceptions;

public class AppointmentIdNotFoundException extends Exception {
/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
public AppointmentIdNotFoundException() {
	// TODO Auto-generated constructor stub
}
public AppointmentIdNotFoundException(String message) {
super(message);
}
}
