package com.cg.onlineeyecare.exceptions;

public class DoctorIdNotFoundException extends Exception {
/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
public DoctorIdNotFoundException() {
	// TODO Auto-generated constructor stub
}
public DoctorIdNotFoundException(String message) {
	super(message);
}
}
