package com.cg.onlineeyecare.exceptions;

public class InvalidAppointmentException extends Exception {
/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
public InvalidAppointmentException() {
	// TODO Auto-generated constructor stub
}
public InvalidAppointmentException(String message) {
	super(message);
}
}
