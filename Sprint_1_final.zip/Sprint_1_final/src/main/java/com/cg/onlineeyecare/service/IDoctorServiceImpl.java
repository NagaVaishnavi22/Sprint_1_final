package com.cg.onlineeyecare.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.onlineeyecare.dao.AppointmentRepository;
import com.cg.onlineeyecare.dao.IDoctorRepository;
import com.cg.onlineeyecare.dao.ITestRepository;
import com.cg.onlineeyecare.dto.Appointment;
import com.cg.onlineeyecare.dto.Doctor;
import com.cg.onlineeyecare.dto.test;
import com.cg.onlineeyecare.exceptions.DoctorIdNotFoundException;


/************************************************************************************
*          @author          K.Muni Madhuri
*          Description      It is a doctor service implementation class that defines the methods
*                           mentioned in its interface.
 *         Version             1.0
 *         Created Date     25-MARCH-2021
************************************************************************************/


@Service
public class IDoctorServiceImpl implements IDoctorService {
	
	@Autowired
	IDoctorRepository doctorRepository;
	
	@Autowired
	ITestRepository testRepository;
	
	@Autowired
	AppointmentRepository appointmentRepo;
	

	/************************************************************************************
	 * Method:                          addDoctor
     *Description:                      It is used to add doctor into doctor table
     * @param doctor:                  doctor's reference variable.
	 * @returns doctor                    It returns doctor with details
     *Created By                      - K.Muni Madhuri
     *Created Date                    - 22-MARCH-2021                           
	 
	 ************************************************************************************/
	
	@Override
	public Doctor addDoctor(Doctor doctor) {
		// TODO Auto-generated method stub
		return doctorRepository.saveAndFlush(doctor);
	}
	

	/************************************************************************************
	 * Method:                          deleteDoctor
     *Description:                      It is used to delete doctor
     *@param doctor:                      doctor's reference variable.
	 * @returns doctor                    It returns the doctor that has been deleted
	 * @throws DoctorIdFoundNotException: It is raised due to invalid doctor.
     *Created By                      - K.Muni Madhuri
     *Created Date                    - 22-MARCH-2021                           
	 
	 ************************************************************************************/
	
	@Override
	public Doctor deleteDoctor(int doctorId) throws DoctorIdNotFoundException {
		// TODO Auto-generated method stub
	Optional<Doctor> result=doctorRepository.findById(doctorId);
		if(result.isPresent())
		{
			doctorRepository.deleteById(doctorId);
			return result.get();
		}
		else
		{
			throw new DoctorIdNotFoundException("please enter valid doctor id");
		}
		//return null;
		
	}
	

	/************************************************************************************
	 * Method:                          viewDoctorsList
     *Description:                      To display all the Doctors
	 * @returns List<doctor>            - It returns all the doctors present in database
     *Created By                      - K.Muni Madhuri
     *Created Date                     - 22-MARCH-2021                           
	 
	 ************************************************************************************/
	
	@Override
	public List<Doctor> viewDoctorsList() {
		return doctorRepository.findAll();
	}

	/************************************************************************************
	 * Method:                          viewDoctor
     *Description:                      To display the doctor by Id (Primary key)
     *@param doctorId:                        id of the doctor.
	 * @returns doctor                 - if doctor with Id presents it returns test else throws DoctorIdFoundNotException
	 * @throws DoctorIdNotFoundException  -  It is raised due to invalid  doctorId 
     *Created By                      - K.Muni Madhuri
     *Created Date                    - 22-MARCH-2021                           
	 
	 ************************************************************************************/

	@Override
	public Doctor viewDoctor(int doctorId) throws DoctorIdNotFoundException {
		java.util.Optional<Doctor> result = doctorRepository.findById(doctorId); 
		if(result.isPresent()) {
			doctorRepository.findById(doctorId);
			return result.get();
		}
		else {
			throw new DoctorIdNotFoundException("please enter valid doctor id");
		}
	}
	

	/************************************************************************************
	 * Method:                          updateDoctor
     *Description:                      It is used to update doctor details into doctor table.
     * @param doctor:                   doctor's reference variable.
	 * @returns doctor                  It returns updated details of the existed doctor.
     *Created By                      - K.Muni Madhuri
     *Created Date                    - 22-MARCH-2021                           
	 
	 ************************************************************************************/
	
	@Override
	public Doctor updateDoctor(Doctor doctor) throws DoctorIdNotFoundException {
		// TODO Auto-generated method stub
		return doctorRepository.save(doctor);
	}
	

	/************************************************************************************
	 * Method:                          viewAppointments
     *Description:                      It is used to view Appointment details.
     * @param Appointment:              Appiontment's reference variable.
	 * @returns Appointment             It returns Appointment details of the doctor.
     *Created By                      - K.Muni Madhuri
     *Created Date                    - 22-MARCH-2021                           
	 
	 ************************************************************************************/
	@Override
	public List<Appointment> viewAllAppointments() {
		// TODO Auto-generated method stub
		//return null;
		return appointmentRepo.findAll();
	}


	/************************************************************************************
	 * Method:                          createTest
     *Description:                      It is used to create test details into test table.
     * @param test:                   test's reference variable.
	 * @returns test                  It returns to test details of the test table.
     *Created By                      - K.Muni Madhuri
     *Created Date                    - 22-MARCH-2021                           
	 
	 ************************************************************************************/
	
	@Override
	public test createTest(test test) {
		return testRepository.saveAndFlush(test);
		
	}


	
	

}
