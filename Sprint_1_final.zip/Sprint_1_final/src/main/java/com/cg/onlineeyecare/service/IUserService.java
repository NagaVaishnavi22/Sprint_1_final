package com.cg.onlineeyecare.service;

import com.cg.onlineeyecare.dto.User;
import com.cg.onlineeyecare.exceptions.PasswordNotMatchException;
import com.cg.onlineeyecare.exceptions.UserNotFoundException;
/****************************************************************************
 * @author               P.saiteja reddy
 * Description           It is a user service interface that describes the abstract methods
 *                       used in its implementation class.
 * version               1.0
 * created date          24-03-2021
 *
 ****************************************************************************/
public interface IUserService {
		public Boolean signIn(User user) throws UserNotFoundException;
		public Boolean signOut(User user) throws UserNotFoundException;
		public User changePassword(String userName, User user) throws UserNotFoundException, PasswordNotMatchException;
	}


