package com.cg.onlineeyecare.service;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import static org.junit.jupiter.api.Assertions.*;
import com.cg.onlineeyecare.dto.User;
import com.cg.onlineeyecare.exceptions.PasswordNotMatchException;
import com.cg.onlineeyecare.exceptions.UserNotFoundException;

@SpringBootTest
public class IUserServiceTest  {
	@Autowired
	private IUserService userService;
	User user= new User("saiteja@123","saireddy76","Doctor");
	User user1= new User("saiteja","tejas94","Doctor");
	User user2=new User("nishanth@123","nishanth21","patient");
	User user3=new User("aravind@34","avi1227","patient");
	User user4=new User("vamsi89","krishna21","patient");
	User user5=new User("manojan321","manojan4","eyespecialist");
	
	
	/***********************************************************
	 * Method                                         testchangePassword
	 * Description                                    It is used to test whether the passowrd is changed or not		
	 * @throws UserNotFoundException                  It is raises due to invalid user details
	 * @throws PasswordNotMatchException              It is raises due to invalid password
	 * created by                                     P.saiteja reddy
	 * created date                                   26-03-2021
	                                                                                   */
	@Test
	void testchangePassword() throws UserNotFoundException, PasswordNotMatchException {
		user=new User("saiteja@123","saireddy76","Doctor");
		
		assertEquals("saireddy76",userService.changePassword("saiteja@123",user).getPassword());
	}
	

	/***********************************************************
	 * Method                                         testSignIn1
	 * Description                                    It is used to test whether user is signed in or not	
	 * @throws UserNotFoundException                  It is raises due to invalid user details
	 * Created by                                     P.saiteja reddy
	 * created date                                   26-03-2021
	                                                                                  */
	
	
	@Test
	void testSignIn1() throws UserNotFoundException {
		assertTrue(userService.signIn(user));
	}
	/***********************************************************
	 * Method                                         testSignOut2
	 * Description                                    It is used to test whether the user is signed out or not	
	 * @throws UserNotFoundException                  It is raises due to invalid user details
	 * created by                                     P.saiteja reddy
	 * created date                                   26-03-2021
	                                                                                   */
	
	
	
	
	@Test
	void testsignOut2() throws UserNotFoundException {
		assertTrue(userService.signOut(user));
	}
	
	/***********************************************************
	 * Method                                         testchangePassword1
	 * Description                                    It is used to test whether the passowrd is changed or not		
	 * @throws UserNotFoundException                  It is raises due to invalid user details
	 * @throws PasswordNotMatchException              It is raises due to invalid password
	 * created by                                     P.saiteja reddy
	 * created date                                   26-03-2021
	                                                                                   */
	
	
	@Test
	void testchangePassword1() throws UserNotFoundException,PasswordNotMatchException {
		user1=new User("saiteja","tejas94","Doctor");
		assertEquals("tejas94",userService.changePassword("saiteja",user1).getPassword());
		
	}
	
	/***********************************************************
	 * Method                                         testSignIn2
	 * Description                                    It is used to test whether the user is signedIn or not		
	 * @throws UserNotFoundException                  It is raises due to invalid user details
	 * created by                                     P.saiteja reddy
	 * created date                                   26-03-2021
	                                                                                   */
	
	@Test
	void testSignIn2() throws UserNotFoundException {
		assertTrue(userService.signIn(user2));
		
	}
	/***********************************************************
	 * Method                                          testsignOut3 
	 * Description                                    It is used to test whether the user is signedOut or not		
	 * @throws UserNotFoundException                  It is raises due to invalid user details
	 * created by                                     P.saiteja reddy
	 * created date                                   26-03-2021
	                                                                                   */
	
	
	@Test
	void testsignOut3() throws UserNotFoundException {
		assertTrue(userService.signOut(user1));
	}
	/***********************************************************
	 * Method                                         testchangePassword2
	 * Description                                    It is used to test whether the passowrd is changed or not		
	 * @throws UserNotFoundException                  It is raises due to invalid user details
	 * @throws PasswordNotMatchException              It is raises due to invalid password
	 * created by                                     P.saiteja reddy
	 * created date                                   26-03-2021
	                                                                                   */
	
	@Test
	void testchangePassword2() throws UserNotFoundException,PasswordNotMatchException {
		user2=new User("nishanth@123","nishanth21","patient");
		assertEquals("nishanth21",userService.changePassword("nishanth@123",user2).getPassword());
	}
	/***********************************************************
	 * Method                                         testSignIn3
	 * Description                                    It is used to test whether the user is signedIn or not	
	 * @throws UserNotFoundException                  It is raises due to invalid user details
	 * created by                                     P.saiteja reddy
	 * created date                                   26-03-2021
	                                                                                   */
	
	
	@Test
	void testSignIn3() throws UserNotFoundException {
		assertTrue(userService.signIn(user2));
	}
	/***********************************************************
	 * Method                                         testsignOut4
	 * Description                                    It is used to test whether the user is signedout or not	
	 * @throws UserNotFoundException                  It is raises due to invalid user details
	 * created by                                     P.saiteja reddy
	 * created date                                   26-03-2021
	                                                                                   */
	
	
	@Test
	void testsignOut4() throws UserNotFoundException {
		assertTrue(userService.signOut(user2));
	}
	/***********************************************************
	 * Method                                         testchangePassword3
	 * Description                                    It is used to test whether the passowrd is changed or not		
	 * @throws UserNotFoundException                  It is raises due to invalid user details
	 * @throws PasswordNotMatchException              It is raises due to invalid password
	 * created by                                     P.saiteja reddy
	 * created date                                   26-03-2021
	                                                                                   */
	
	@Test
	void testchangePassword3() throws UserNotFoundException,PasswordNotMatchException {
		user3=new User("aravind@34","avi1227","patient");
		assertEquals("avi1227",userService.changePassword("aravind@34",user3).getPassword());
	}
	/***********************************************************
	 * Method                                          testSignIn4
	 * Description                                    It is used to test whether the user is signedIn or not	
	 * @throws UserNotFoundException                  It is raises due to invalid user details
	 * created by                                     P.saiteja reddy
	 * created date                                   26-03-2021
	                                                                                   */
	
	@Test
	void testSignIn4() throws UserNotFoundException {
		assertTrue(userService.signIn(user3));
	}
	/***********************************************************
	 * Method                                         testsignOut5(
	 * Description                                    It is used to test whether user is signedout or not	
	 * @throws UserNotFoundException                  It is raises due to invalid user details
	 * created by                                     P.saiteja reddy
	 * created date                                   26-03-2021
	                                                                                   */
	
	@Test
	void testsignOut5() throws UserNotFoundException {
		assertTrue(userService.signOut(user3));
	}
	/***********************************************************
	 * Method                                         testchangePassword4
	 * Description                                    It is used to test whether the passowrd is changed or not		
	 * @throws UserNotFoundException                  It is raises due to invalid user details
	 * @throws PasswordNotMatchException              It is raises due to invalid password
	 * created by                                     P.saiteja reddy
	 * created date                                   26-03-2021
	                                                                                   */
	
	@Test
	void testchangePassword4() throws UserNotFoundException,PasswordNotMatchException {
		user4=new User("vamsi89","krishna21","patient");
		assertEquals("krishna21",userService.changePassword("vamsi89",user4).getPassword());
	}
	/***********************************************************
	 * Method                                         testSignIn5
	 * Description                                    It is used to test whether the user is signedIn or not	
	 * @throws UserNotFoundException                  It is raises due to invalid user details
	 * created by                                     P.saiteja reddy
	 * created date                                   26-03-2021
	                                                                                   */
	
	@Test
	void testSignIn5() throws UserNotFoundException {
		assertTrue(userService.signIn(user4));
	}
	/***********************************************************
	 * Method                                         testsignOut6
	 * Description                                    It is used to test whether the user is signedOut or not	
	 * @throws UserNotFoundException                  It is raises due to invalid user details
	 * created by                                     P.saiteja reddy
	 * created date                                   26-03-2021
	                                                                                   */
	
	@Test
	void testsignOut6() throws UserNotFoundException {
		assertTrue(userService.signOut(user4));
	}
	
		
	
	


}
