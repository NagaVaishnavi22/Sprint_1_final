package com.cg.onlineeyecare.service;
import static org.junit.jupiter.api.Assertions.*;
import java.time.LocalDate;
import java.time.LocalTime;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.cg.onlineeyecare.dto.Appointment;
import com.cg.onlineeyecare.dto.Doctor;
import com.cg.onlineeyecare.dto.Patient;
import com.cg.onlineeyecare.exceptions.AppointmentIdNotFoundException;
import com.cg.onlineeyecare.exceptions.PatientIdFoundNotException;
import com.cg.onlineeyecare.service.PatientService;
@SpringBootTest
class PatientserviceTest1 {

   @Autowired
   private PatientService patientservice;
   @Autowired
   private AppointmentService appointmentservice;
   @Test
   public void addPatientTest() {
    Patient tempPatient=new Patient(1098,"lee",20,898978,"lee@",LocalDate.now(),"lee","1234","hyd");
     assertEquals(1098,patientservice.addPatient(tempPatient).getPatientId());
   }
   @Test
	void viewPatient() throws PatientIdFoundNotException
	{
		assertEquals(20,patientservice.viewPatient(1098).getPatientAge());
	} 
   @Test
	void viewAllPatientTest()
	{
		//it checks if the first patientid of first patient in the list is equal to 1 or not
		assertEquals(10,patientservice.viewPatientList().get(0).getPatientId());
	}
   @Test
	void updatePatientTest()  {
		//here the cnsultation fee is update to 5000.25
	   Patient tempPatient=new Patient(1098,"lee",20,898978,"lee@",LocalDate.now(),"lee","1234","hyd");
	    assertEquals(1098,patientservice.updatePatient(tempPatient).getPatientId());
		
	}
	@Test
	void deletePatientTest() throws PatientIdFoundNotException{
		assertEquals(1098,patientservice.deletePatient(1098).getPatientId());
	}
//	@Test
//	void bookApointmentTest()
//	{
//		Appointment tempAppointment=new Appointment(9406,LocalDate.now(),LocalTime.now(),1000D);
//		//Here we are checking the above apppointment is added or not
//		assertEquals(9406,patientservice.bookAppointment(tempAppointment).getAppointmentId());
//	}
	@Test
	void bookApointmentTest()
	{
		Appointment tempAppointment=new Appointment(9406,LocalDate.now(),LocalTime.now(),2500.5,
				new Doctor(1,"abc","10",848675437,"abc@mail","abc","abc","gydg", null),new Patient(1,"abg",45,74764665,"abg@mqail",LocalDate.now(),"abg","abg","hyd"));
		//Here we are checking the above appointment is added or not
		assertEquals(9406,patientservice.bookAppointment(tempAppointment).getAppointmentId());
	}
//	@Test
//	void viewAppointmentById() throws AppointmentIdNotFoundException
//	{
//		assertEquals(2500.5,patientservice.viewAppointmentDetails(9406).getConsultantFee());
//	}
	

}

